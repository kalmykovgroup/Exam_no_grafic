﻿// Game 2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "Header.h"
#include "Game.h"
int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	Game game;
	game.start();
}

 